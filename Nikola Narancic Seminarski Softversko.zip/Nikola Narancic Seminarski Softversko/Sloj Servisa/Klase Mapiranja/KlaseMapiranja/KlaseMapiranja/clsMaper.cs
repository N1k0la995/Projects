﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
//
using Klasa_Podataka;
using System.Data;
namespace KlaseMapiranja
{
    public class clsMaper
    {
        private string pStringKonekcije;

        // property

        // konstruktor
        public clsMaper(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }


        public string DajSifruSaleZaWebServis(string IdSaleIzBazePodataka)
        {
            string IDSaleWS = "";
            clsSalaDB objSalaDB = new clsSalaDB(pStringKonekcije);
            string nazivSaleIzBazePodataka = objSalaDB.DajSaluPremaIDSale(IdSaleIzBazePodataka);

            IDSaleWS = nazivSaleIzBazePodataka[0].ToString();

            return IDSaleWS;

        }
    }
}
