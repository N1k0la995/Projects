﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klasa_Podataka
{
    public class clsSalaLista
    {

        private List<clsSala> pListaSale;

        // property
        public List<clsSala> ListaSale
        {
            get
            {
                return pListaSale;
            }
            set
            {
                if (this.pListaSale != value)
                    this.pListaSale = value;
            }
        }

        // konstruktor
        public clsSalaLista()
        {
            pListaSale = new List<clsSala>();

        }

        // privatne metode

        // javne metode
        public void DodajElementListe(clsSala objNovaSala)
        {
            pListaSale.Add(objNovaSala);
        }

        public void ObrisiElementListe(clsSala objSalaZaBrisanje)
        {
            pListaSale.Remove(objSalaZaBrisanje);
        }

        public void ObrisiElementNaPoziciji(int pozicija)
        {
            pListaSale.RemoveAt(pozicija);
        }

        public void IzmeniElementListe(clsSala objStaraSala, clsSala objNovaSala)
        {
            int indexStareSale = 0;
            indexStareSale = pListaSale.IndexOf(objStaraSala);
            pListaSale.RemoveAt(indexStareSale);
            pListaSale.Insert(indexStareSale, objNovaSala);
        }

    }
}
