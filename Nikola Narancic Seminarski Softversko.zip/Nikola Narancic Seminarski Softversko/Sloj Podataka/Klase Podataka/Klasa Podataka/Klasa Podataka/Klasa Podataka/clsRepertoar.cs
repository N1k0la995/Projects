﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klasa_Podataka
{
    public class clsRepertoar
    {
        private int pSifra;
        private string pNaziv;
        private string pGlumci;
        private string pOpis;
        private string pDatum;
        private clsSala objSala;


        public int Sifra
        {
            get { return pSifra; }
            set { pSifra = value; }
        }



        public string Naziv
        {
            get { return pNaziv; }
            set { pNaziv = value; }
        }



        public string Glumci
        {
            get { return pGlumci; }
            set { pGlumci = value; }
        }

        public string Opis
        {
            get { return pOpis; }
            set { pOpis = value; }
        }

        public string Datum
        {
            get { return pDatum; }
            set { pDatum = value; }
        }



        public clsSala Sala
        {
            get { return objSala; }
            set { objSala = value; }
        }
    }
}
