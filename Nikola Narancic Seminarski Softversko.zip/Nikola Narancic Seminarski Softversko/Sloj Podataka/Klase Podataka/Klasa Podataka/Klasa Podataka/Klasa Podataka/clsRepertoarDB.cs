﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
namespace Klasa_Podataka
{
    public class clsRepertoarDB
    {

        private string pStringKonekcije;

        // property
        // 1. nacin
        public string StringKonekcije
        {
            get
            {
                return pStringKonekcije;
            }
        }
        // konstruktor
        // 2. nacin prijema vrednosti stringa konekcije spolja i dodele atributu
        public clsRepertoarDB(string NoviStringKonekcije)
        // OVO JE DOBRO JER OBAVEZUJE DA SE PRILIKOM INSTANCIRANJA OVE KLASE
        // MORA OBEZBEDITI STRING KONEKCIJE
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        // privatne metode

        // javne metode
        public DataSet DajSveRepertoare()
        {
            DataSet dsPodaci = new DataSet();

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();
            SqlCommand Komanda = new SqlCommand("DajSveRepertoareSaJoin", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = Komanda;
            da.Fill(dsPodaci);
            Veza.Close();
            Veza.Dispose();

            return dsPodaci;
        }

        public DataSet DajRepertoarPoNazivu(string Naziv)
        {
            // MOGU biti jos neke procedure, mogu SE VRATITI VREDNOSTI I U LISTU, DATA TABLE...
            DataSet dsPodaci = new DataSet();

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();
            SqlCommand Komanda = new SqlCommand("DajRepertoarePoNazivu", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@Naziv", SqlDbType.NVarChar).Value = Naziv;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = Komanda;
            da.Fill(dsPodaci);
            Veza.Close();
            Veza.Dispose();

            return dsPodaci;
        }



        public int DajSveRepertoareSaJoinSifromZvanja(string IDSale)
        {
            int ukupnoNastavnika = 0;
            DataSet dsPodaci = new DataSet();
            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();
            SqlCommand Komanda = new SqlCommand("DajSveRepertoareSaJoinSifromSale", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@IDSale", SqlDbType.Char).Value = IDSale;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = Komanda;
            da.Fill(dsPodaci);
            Veza.Close();
            Veza.Dispose();
            ukupnoNastavnika = int.Parse(dsPodaci.Tables[0].Rows[0].ItemArray[0].ToString());
            return ukupnoNastavnika;
        }


        public clsRepertoarLista DajListuSvihRepertoara()
        {
            // PRIPREMA PROMENLJIVIH
            clsRepertoarLista objRepertoarLista = new clsRepertoarLista();
            DataSet dsPodaciRepertoara = new DataSet();
            clsRepertoar objRepertoar;
            clsSala objSala;

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();
            SqlCommand Komanda = new SqlCommand("DajSveFilmoveSaJoinSifromZanra", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = Komanda;
            da.Fill(dsPodaciRepertoara);
            Veza.Close();
            Veza.Dispose();

            // FORMIRANJE OBJEKATA I UBACIVANJE U LISTU
            for (int brojac = 0; brojac < dsPodaciRepertoara.Tables[0].Rows.Count; brojac++)
            {
                objSala = new clsSala();
                objSala.Sifra = dsPodaciRepertoara.Tables[0].Rows[brojac].ItemArray[4].ToString();
                objSala.Naziv = dsPodaciRepertoara.Tables[0].Rows[brojac].ItemArray[3].ToString();

                objRepertoar = new clsRepertoar();
                objRepertoar.Sifra = int.Parse(dsPodaciRepertoara.Tables[0].Rows[brojac].ItemArray[0].ToString());
                objRepertoar.Naziv = dsPodaciRepertoara.Tables[0].Rows[brojac].ItemArray[0].ToString();
                objRepertoar.Glumci = dsPodaciRepertoara.Tables[0].Rows[brojac].ItemArray[0].ToString();
                objRepertoar.Datum = dsPodaciRepertoara.Tables[0].Rows[brojac].ItemArray[0].ToString();
                objRepertoar.Sala = objSala;
                objRepertoarLista.DodajElementListe(objRepertoar);
            }

            return objRepertoarLista;
        }


        public bool SnimiNoviRepertoar(clsRepertoar objNoviRepertoar)
        {
            // LOKALNE PROMENLJIVE UVEK NA VRHU
            int brojSlogova = 0;

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();

            SqlCommand Komanda = new SqlCommand("DodajNovoiFilm", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@Sifra", SqlDbType.Int).Value = objNoviRepertoar.Sifra;
            Komanda.Parameters.Add("@Naziv", SqlDbType.NVarChar).Value = objNoviRepertoar.Naziv;
            Komanda.Parameters.Add("@Glumac", SqlDbType.NVarChar).Value = objNoviRepertoar.Glumci;
            Komanda.Parameters.Add("@Datum", SqlDbType.NVarChar).Value = objNoviRepertoar.Datum;
            Komanda.Parameters.Add("@IDSale", SqlDbType.Char).Value = objNoviRepertoar.Sala.Sifra;


            brojSlogova = Komanda.ExecuteNonQuery();
            Veza.Close();
            Veza.Dispose();

            // 2. varijanta
            return (brojSlogova > 0);

        }

        public bool ObrisiRepertoar(string sifraRepertoaraZaBrisanje)
        {
            // LOKALNE PROMENLJIVE UVEK NA VRHU
            int brojSlogova = 0;
            // 1. varijanta - skolska 
            //bool uspehSnimanja= false;

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();

            SqlCommand Komanda = new SqlCommand("ObrisiRepertoar", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@Sifra", SqlDbType.Int).Value = sifraRepertoaraZaBrisanje;
            brojSlogova = Komanda.ExecuteNonQuery();
            Veza.Close();
            Veza.Dispose();

            return (brojSlogova > 0);

        }

        public bool IzmeniRepertoar(clsRepertoar objStariRepertoar, clsRepertoar objNoviRepertoar)
        {
            // LOKALNE PROMENLJIVE UVEK NA VRHU
            int brojSlogova = 0;
            // 1. varijanta - skolska 
            //bool uspehSnimanja= false;

            SqlConnection Veza = new SqlConnection(pStringKonekcije);
            Veza.Open();

            SqlCommand Komanda = new SqlCommand("IzmeniRepertoar", Veza);
            Komanda.CommandType = CommandType.StoredProcedure;
            Komanda.Parameters.Add("@StaraSifra", SqlDbType.Int).Value = objStariRepertoar.Sifra;
            Komanda.Parameters.Add("@Sifra", SqlDbType.Int).Value = objNoviRepertoar.Sifra;
            Komanda.Parameters.Add("@Naziv", SqlDbType.NVarChar).Value = objNoviRepertoar.Naziv;
            Komanda.Parameters.Add("@Glumci", SqlDbType.NVarChar).Value = objNoviRepertoar.Glumci;
            Komanda.Parameters.Add("@Datum", SqlDbType.NVarChar).Value = objNoviRepertoar.Datum;
            Komanda.Parameters.Add("@IDSale", SqlDbType.Char).Value = objNoviRepertoar.Sala.Sifra;
            brojSlogova = Komanda.ExecuteNonQuery();
            Veza.Close();
            Veza.Dispose();

            return (brojSlogova > 0);

        }

    }
}
