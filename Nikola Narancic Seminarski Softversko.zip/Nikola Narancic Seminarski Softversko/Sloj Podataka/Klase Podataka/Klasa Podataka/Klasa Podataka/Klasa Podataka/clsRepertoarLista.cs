﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Klasa_Podataka
{
    public class clsRepertoarLista
    {

        // atributi
        private List<clsRepertoar> pListaRepertoara;

        // property
        public List<clsRepertoar> ListaRepertoara
        {
            get
            {
                return pListaRepertoara;
            }
            set
            {
                if (this.pListaRepertoara != value)
                    this.pListaRepertoara = value;
            }
        }

        // konstruktor
        public clsRepertoarLista()
        {
            pListaRepertoara = new List<clsRepertoar>();

        }

        // privatne metode

        // javne metode
        public void DodajElementListe(clsRepertoar objNoviRepertoar)
        {
            pListaRepertoara.Add(objNoviRepertoar);
        }

        public void ObrisiElementListe(clsRepertoar objRepertoarZaBrisanje)
        {
            pListaRepertoara.Remove(objRepertoarZaBrisanje);
        }

        public void ObrisiElementNaPoziciji(int pozicija)
        {
            pListaRepertoara.RemoveAt(pozicija);
        }

        public void IzmeniElementListe(clsRepertoar objStariRepertoar, clsRepertoar objNoviRepertoar)
        {
            int indexStarogRepertoara = 0;
            indexStarogRepertoara = pListaRepertoara.IndexOf(objNoviRepertoar);
            pListaRepertoara.RemoveAt(indexStarogRepertoara);
            pListaRepertoara.Insert(indexStarogRepertoara, objNoviRepertoar);
        }

    }
}
