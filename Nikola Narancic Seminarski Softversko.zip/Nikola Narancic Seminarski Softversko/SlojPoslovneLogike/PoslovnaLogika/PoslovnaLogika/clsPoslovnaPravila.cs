﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WSUniverzitet;
using Klasa_Podataka;
using KlaseMapiranja;
namespace PoslovnaLogika
{
    public class clsPoslovnaPravila
    {
        private string pStringKonekcije;

        public clsPoslovnaPravila(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }
        public bool DaLiJeZaSveUzraste(string IdRepertoaraIzBazePodataka)
        {
         


            bool Moze = false;

          
            int Godiste = 0;
            clsRepertoarDB objRepertoarDB = new clsRepertoarDB(pStringKonekcije);
            Godiste = objRepertoarDB.DajSveRepertoareSaJoinSifromZvanja(IdRepertoaraIzBazePodataka);

            
            string IDSalaWS = "";
            clsMaper objMaper = new clsMaper(pStringKonekcije);
            IDSalaWS = objMaper.DajSifruSaleZaWebServis(IdRepertoaraIzBazePodataka);

           
            KadrovskiPodaci.Service1 objOgranicenja = new KadrovskiPodaci.Service1();
            int  Uzrast= objOgranicenja.DajOpisRepertoara(IDSalaWS);

          
            if (Godiste < Uzrast)
            {
                Moze = true;
            }
            else
            {
                Moze = false;
            }


            return Moze;
        }
    }
}
