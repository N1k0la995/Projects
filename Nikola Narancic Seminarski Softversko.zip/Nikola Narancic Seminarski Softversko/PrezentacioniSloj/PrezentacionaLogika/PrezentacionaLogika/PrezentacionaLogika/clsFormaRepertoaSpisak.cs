﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Klasa_Podataka;
namespace PrezentacionaLogika
{
    public  class clsFormaRepertoaSpisak
    {
        private string pStringKonekcije;

        public clsFormaRepertoaSpisak(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaGrid(string filter)
        {
            DataSet dsPodaci = new DataSet();
            clsRepertoarDB objRepertoarDB = new clsRepertoarDB(pStringKonekcije);
            if (filter.Equals(""))
            {
                dsPodaci = objRepertoarDB.DajSveRepertoare();
            }
            else
            {
                dsPodaci = objRepertoarDB.DajRepertoarPoNazivu(filter);
            }
            return dsPodaci;
        }
    }
}
