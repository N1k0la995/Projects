﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using Klasa_Podataka;
namespace PrezentacionaLogika
{
    public class clsFormaSalaTabelaEdit
    {
        private string pStringKonekcije;

        // property

        // konstruktor
        public clsFormaSalaTabelaEdit(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaGrid(string filter)
        {
            DataSet dsPodaci = new DataSet();
            clsSalaDB objSalaDB = new clsSalaDB(pStringKonekcije);
            if (filter.Equals(""))
            {
                dsPodaci = objSalaDB.DajSveSale();
            }
            else
            {
                dsPodaci = objSalaDB.DajSalePoNazivu(filter);
            }
            return dsPodaci;
        }
    }
}
