﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using PoslovnaLogika;
using Klasa_Podataka;
namespace PrezentacionaLogika
{
    public  class clsFormaRepertoaUnos
    {
        private string pStringKonekcije;
        private string pSifra;
        private string pNaziv;
        private string pGlumci;
        private string pOpis;
        private string pDatum;
        private string pSala;

        // property
        public string Sifra
        {
            get { return pSifra; }
            set { pSifra = value; }
        }

        public string Naziv
        {
            get { return pNaziv; }
            set { pNaziv = value; }
        }

        public string Glumci
        {
            get { return pGlumci; }
            set { pGlumci = value; }
        }
        public string Opis
        {
            get { return pOpis; }
            set { pOpis = value; }
        }

        public string Datum
        {
            get { return pDatum; }
            set { pDatum = value; }
        }


        public string Sala
        {
            get { return pSala; }
            set { pSala = value; }
        }

        // konstruktor
        public clsFormaRepertoaUnos(string NoviStringKonekcije)
        {
            pStringKonekcije = NoviStringKonekcije;
        }

        // private metode

        // public metode
        public DataSet DajPodatkeZaCombo()
        {
            DataSet dsPodaci = new DataSet();
            clsSalaDB objSalaDB = new clsSalaDB(pStringKonekcije);

            dsPodaci = objSalaDB.DajSveSale();

            return dsPodaci;
        }

        public bool DaLiJeSvePopunjeno()
        {
            bool SvePopunjeno = false;

            // PITANJE U NEGATIVNOM KONTEKSTU if ((txbJMBG.Text.Length == 0) || (txbPrezime.Text.Length == 0) || (txbIme.Text.Length == 0) || (ddlZvanje.Text.Length == 0) || (ddlZvanje.Text == "Izaberite..."))

            // PRERADA KODA - IF (da li nesto jeste)

            if ((pSifra.Length > 0) && (pNaziv.Length > 0) && (pGlumci.Length > 0) && (pOpis.Length > 0) && (pDatum.Length > 0) && (pSala.Length > 0) && (!pSala.Equals("Izaberite...")))
            {
                SvePopunjeno = true;
            }
            else
            {
                SvePopunjeno = false;
            }

            return SvePopunjeno;
        }


        public bool DaLiJeJedinstvenZapis()
        {
            bool JedinstvenZapis = false;
            DataSet dsPodaci = new DataSet();
            clsRepertoarDB objRepertoarDB = new clsRepertoarDB(pStringKonekcije);
            dsPodaci = objRepertoarDB.DajRepertoarPoNazivu(pNaziv);

            if (dsPodaci.Tables[0].Rows.Count == 0)
            {
                JedinstvenZapis = true;
            }
            else
            {
                JedinstvenZapis = false;
            }

            return JedinstvenZapis;

        }

        public bool SnimiPodatke()
        {
            bool uspehSnimanja = false;

            clsRepertoarDB objRepertoarDB = new clsRepertoarDB(pStringKonekcije);

            clsRepertoar objNoviRepertoar= new clsRepertoar();
            objNoviRepertoar.Sifra = int.Parse(pSifra);
            objNoviRepertoar.Naziv = pNaziv;
            objNoviRepertoar.Glumci = pGlumci;
            objNoviRepertoar.Datum = pDatum;
            objNoviRepertoar.Opis = pOpis;


            clsSala objSala = new clsSala();

            clsSalaDB objSalaDB = new clsSalaDB(pStringKonekcije);
            objSala.Sifra = objSalaDB.DajSifruSalePoNazivu(pSifra);
            objSala.Naziv = pNaziv;

            objNoviRepertoar.Sala = objSala;

            uspehSnimanja = objRepertoarDB.SnimiNoviRepertoar(objNoviRepertoar);


            return uspehSnimanja;
        }

        public bool DaLiSuPodaciUskladjeniSaPoslovnimPravilima()
        {
            // POSLOVNO PRAVILO:
            // Na fakultetu ne moze biti zaposleno vise nastavnika u odredjenom
            // zvanju nego sto je dozvoljeno maksimalnim brojem prema Sistematizaciji
            // radnih mesta.
            bool UskladjeniPodaci = false;

            clsPoslovnaPravila objPoslovnaPravila = new clsPoslovnaPravila(pStringKonekcije);

            //izracunavanje ID zvanja
            clsSalaDB objSalaDB = new clsSalaDB(pStringKonekcije);
            string IDSale = objSalaDB.DajSifruSalePoNazivu(pNaziv);

            UskladjeniPodaci = objPoslovnaPravila.DaLiJeZaSveUzraste(Sifra);

            return UskladjeniPodaci;
        }
    }
}
