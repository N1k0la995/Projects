﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace KorisnickiInterfejs
{
    public partial class ZvanjeDetaljiEdit : System.Web.UI.Page
    {
        private string pSifra = "";

        private void PrikaziPodatke(string sifra)
        {
            txbSifra.Text = sifra; 

        }


        protected void Page_Load(object sender, EventArgs e)
        {
            pSifra = Request.QueryString["Sifra"].ToString();
            PrikaziPodatke(pSifra);
        }
    }
}