﻿using System;
//
using System.Data;
using System.Configuration;
using PrezentacionaLogika;
namespace KorisnickiInterfejs
{
    public partial class RepertoarSpisak : System.Web.UI.Page
    {
        // atributi
        private clsFormaRepertoaSpisak objFormaRepertoarSpisak;

        // konstruktor


        // nase metode
        private void NapuniGrid(DataSet ds)
        {
            // povezivanje grida sa datasetom
            gvSala.DataSource = ds.Tables[0];
            gvSala.DataBind();
        }

      
         
        // dogadjaji
        protected void Page_Load(object sender, EventArgs e)
        {
            objFormaRepertoarSpisak = new clsFormaRepertoaSpisak(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ConnectionString);  
        }

        protected void btnFiltriraj_Click(object sender, EventArgs e)
        {
            NapuniGrid(objFormaRepertoarSpisak.DajPodatkeZaGrid(txbFilter.Text));   
        }

        protected void btnSvi_Click(object sender, EventArgs e)
        {
            NapuniGrid(objFormaRepertoarSpisak.DajPodatkeZaGrid(""));   
        }
    }
}