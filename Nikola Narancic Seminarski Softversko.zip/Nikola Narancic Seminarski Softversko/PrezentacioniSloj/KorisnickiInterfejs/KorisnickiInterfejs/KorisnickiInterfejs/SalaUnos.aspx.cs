﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using Klasa_Podataka;
using DBUtils;
using System.Configuration; 

namespace KorisnickiInterfejs
{
    public partial class SalaUnos : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSnimi_Click(object sender, EventArgs e)
        {
            clsSalaDB objSalaDB = new clsSalaDB(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ToString());
            clsSala objSala = new clsSala();
            objSala.Naziv = txbNaziv.Text;
            objSala.Sifra = txbSifra.Text;
            objSalaDB.SnimiNovuSalu(objSala);
            lblStatus.Text = "Snimljeno";
        }

        protected void btnOdustani_Click(object sender, EventArgs e)
        {

        }
    }
}