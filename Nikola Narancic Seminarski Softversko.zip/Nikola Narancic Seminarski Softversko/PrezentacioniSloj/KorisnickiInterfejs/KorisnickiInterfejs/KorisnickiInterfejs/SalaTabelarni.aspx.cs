﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
//
using DBUtils;
using System.Configuration;
using System.Data;
using Klasa_Podataka;
namespace KorisnickiInterfejs
{
    public partial class SalaTabelarni : System.Web.UI.Page
    {
              
        
        private void NapuniGrid(DataSet ds)
        {
            // povezivanje grida sa datasetom
            gvSpisakSala.DataSource = ds.Tables[0];
            gvSpisakSala.DataBind();
        }
        
        
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnFiltriraj_Click(object sender, EventArgs e)
        {
            clsSalaDB objSalaDB = new clsSalaDB(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ToString());
            NapuniGrid(objSalaDB.DajSalePoNazivu(txbFilter.Text)); 
        }
        
        protected void btnSvi_Click(object sender, EventArgs e)
        {
            clsSalaDB objSalaDB = new clsSalaDB(ConfigurationManager.ConnectionStrings["NasaKonekcija"].ToString());
            NapuniGrid(objSalaDB.DajSveSale()); 
        }
    }
}